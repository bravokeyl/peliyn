<?php
/*
Plugin Name: Dishes and Testimonials
Plugin URI: http://cloudspier.com
Description: Dishes Custom Post Type written for Peliyn(Leaff) Theme
Version: 1.0
Author: bravokeyl
Author URI: http://cloudspier.com
License: GPL3
License URI: https://www.gnu.org/licenses/gpl-3.0.html
Domain Path: /languages
Text Domain: dishes-peliyn
*/
/*
Dishes and Testimonials  is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
any later version.
 
Dishes and Testimonials is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.
 
You should have received a copy of the GNU General Public License
along with Dishes and Testimonials. If not, see https://www.gnu.org/licenses/gpl-3.0.html.
*/

function peliyn_cptts() {

	$dishes_labels = array(
		'name'                => _x( 'Dishes', 'Post Type General Name', 'peliyn' ),
		'singular_name'       => _x( 'Dish', 'Post Type Singular Name', 'peliyn' ),
		'menu_name'           => __( 'Dishes', 'peliyn' ),
		'parent_item_colon'   => __( 'Parent Dish:', 'peliyn' ),
		'all_items'           => __( 'All Dishes', 'peliyn' ),
		'view_item'           => __( 'View Dish', 'peliyn' ),
		'add_new_item'        => __( 'Add New Dish', 'peliyn' ),
		'add_new'             => __( 'Add New', 'peliyn' ),
		'edit_item'           => __( 'Edit Dish', 'peliyn' ),
		'update_item'         => __( 'Update Dish', 'peliyn' ),
		'search_items'        => __( 'Search Dish', 'peliyn' ),
		'not_found'           => __( 'Not found', 'peliyn' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'peliyn' ),
	);
	$dishes_rewrite = array(
		'slug'                => 'dishes',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true,
	);
	$dishes_args = array(
		'label'               => __( 'p_dishes', 'peliyn' ),
		'description'         => __( '', 'peliyn' ),
		'labels'              => $dishes_labels,
		'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'trackbacks', 'revisions', 'custom-fields', ),
		'taxonomies'          => array( 'post_tag' ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'menu_icon' => 'dashicons-carrot',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'query_var'           => 'dish',
		'rewrite'             => $dishes_rewrite,
		'capability_type'     => 'post',
	);
	register_post_type( 'p_dishes', $dishes_args );

	$testimonials_labels = array(
		'name'                => _x( 'Testimonials', 'Post Type General Name', 'peliyn' ),
		'singular_name'       => _x( 'Testimonial', 'Post Type Singular Name', 'peliyn' ),
		'menu_name'           => __( 'Testimonials', 'peliyn' ),
		'parent_item_colon'   => __( 'Parent Testimonial:', 'peliyn' ),
		'all_items'           => __( 'All Testimonials', 'peliyn' ),
		'view_item'           => __( 'View Testimonial', 'peliyn' ),
		'add_new_item'        => __( 'Add New Testimonial', 'peliyn' ),
		'add_new'             => __( 'Add New', 'peliyn' ),
		'edit_item'           => __( 'Edit Testimonial', 'peliyn' ),
		'update_item'         => __( 'Update Testimonial', 'peliyn' ),
		'search_items'        => __( 'Search Testimonial', 'peliyn' ),
		'not_found'           => __( 'Not found', 'peliyn' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'peliyn' ),
	);
	$testimonials_rewrite = array(
		'slug'                => 'testimonials',
		'with_front'          => true,
		'pages'               => true,
		'feeds'               => true,
	);
	$testimonials_args = array(
		'label'               => __( 'p_testimonials', 'peliyn' ),
		'description'         => __( '', 'peliyn' ),
		'labels'              => $testimonials_labels,
		'supports'            => array( 'title', 'editor', 'author', 'thumbnail', ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => false,
		'show_in_admin_bar'   => false,
		'menu_position'       => 15,
		'menu_icon' => 'dashicons-heart',
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => true,
		'publicly_queryable'  => true,
		'query_var'           => 'testimonial',
		'rewrite'             => $testimonials_rewrite,
		'capability_type'     => 'post',
	);
	register_post_type( 'p_testimonials', $testimonials_args );

	$dishtax_labels = array(
		'name'                       => _x( 'Varities', 'Taxonomy General Name', 'peliyn' ),
		'singular_name'              => _x( 'Variety', 'Taxonomy Singular Name', 'peliyn' ),
		'menu_name'                  => __( 'Variety', 'peliyn' ),
		'all_items'                  => __( 'All Varities', 'peliyn' ),
		'parent_item'                => __( 'Parent Item', 'peliyn' ),
		'parent_item_colon'          => __( 'Parent Item:', 'peliyn' ),
		'new_item_name'              => __( 'New Variety', 'peliyn' ),
		'add_new_item'               => __( 'Add New Variety', 'peliyn' ),
		'edit_item'                  => __( 'Edit Variety', 'peliyn' ),
		'update_item'                => __( 'Update Variety', 'peliyn' ),
		'separate_items_with_commas' => __( 'Separate items with commas', 'peliyn' ),
		'search_items'               => __( 'Search Items', 'peliyn' ),
		'add_or_remove_items'        => __( 'Add or remove items', 'peliyn' ),
		'choose_from_most_used'      => __( 'Choose from the most used items', 'peliyn' ),
		'not_found'                  => __( 'Not Found', 'peliyn' ),
	);
	$dishtax_rewrite = array(
		'slug'                       => 'variety',
		'with_front'                 => true,
		'hierarchical'               => false,
	);
	$dishtax_args = array(
		'labels'                     => $dishtax_labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
		'query_var'                  => 'variety',
		'rewrite'                    => $dishtax_rewrite,
	);
	register_taxonomy( 'dishtax', array( 'p_dishes' ), $dishtax_args );

}
add_action( 'init', 'peliyn_cptts' );

function dishes_peliyn_install() {
 
    peliyn_cptts();

    flush_rewrite_rules();
 
}
register_activation_hook( __FILE__, 'dishes_peliyn_install' );